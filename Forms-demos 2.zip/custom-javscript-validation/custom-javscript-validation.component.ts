import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { CustomValidators } from '../custom-JS-Validators';
@Component({
  selector: 'app-custom-javscript-validation',
  templateUrl: './custom-javscript-validation.component.html',
  styleUrls: ['./custom-javscript-validation.component.css']
})
export class CustomJavscriptValidationComponent {
  loginForm: FormGroup;

  constructor(fromBuilder: FormBuilder){

    this.loginForm = fromBuilder.group({
        email: ['', Validators.compose([Validators.required, CustomValidators.emailValidator])],
        password  : ['', Validators.required]
    });
}


  onSubmit() {
    if(this.loginForm.valid) {
        console.log(this.loginForm);
    }
}
}
