import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomJavscriptValidationComponent } from './custom-javscript-validation.component';

describe('CustomJavscriptValidationComponent', () => {
  let component: CustomJavscriptValidationComponent;
  let fixture: ComponentFixture<CustomJavscriptValidationComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CustomJavscriptValidationComponent]
    });
    fixture = TestBed.createComponent(CustomJavscriptValidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
