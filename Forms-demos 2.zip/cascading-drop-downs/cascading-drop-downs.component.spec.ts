import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CascadingDropDownsComponent } from './cascading-drop-downs.component';

describe('CascadingDropDownsComponent', () => {
  let component: CascadingDropDownsComponent;
  let fixture: ComponentFixture<CascadingDropDownsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CascadingDropDownsComponent]
    });
    fixture = TestBed.createComponent(CascadingDropDownsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
