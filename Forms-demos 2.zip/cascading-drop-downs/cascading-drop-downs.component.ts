import { Component } from '@angular/core';

@Component({
  selector: 'app-cascading-drop-downs',
  templateUrl: './cascading-drop-downs.component.html',
  styleUrls: ['./cascading-drop-downs.component.css']
})
export class CascadingDropDownsComponent 
{
  Countries: Array<any> = [
		{ name: 'Germany', states: [ {name: 'A', cities: ['Duesseldorf', 'Leinfelden-Echterdingen', 'Eschborn']} ] },
		{ name: 'Spain', states: [ {name: 'B', cities: ['Barcelona']} ] },
		{ name: 'USA', states: [ {name: 'C', cities: ['Downers Grove']} ] },
		{ name: 'Mexico', states: [ {name: 'D', cities: ['Puebla']} ] },
		{ name: 'India', states: [ {name: 'E', cities: ['Delhi', 'Kolkata', 'Mumbai', 'Bangalore']} ] },
	];
  selectedCountry: String = "--Choose Country--";
  states: Array<any> = []; 

  cities: Array<any> = [];  


  changeCountry(country: any) 
  {  
		 
		this.states = this.Countries.find((cntry: any) => cntry.name == country.target.value).states; //Angular 11
	 console.log("states selected" + JSON.stringify(this.states));
  }

 
	changeState(state: any) { 
		 
		this.cities = this.Countries.find((cntry: any) => cntry.name == this.selectedCountry).states.find((stat: any) => stat.name == state.target.value).cities; //Angular 11
    console.log("cities " + this.cities);
  }
}
