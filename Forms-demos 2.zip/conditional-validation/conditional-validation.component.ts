import { Component ,OnInit} from '@angular/core';
import { FormBuilder, Validators, FormGroup } from "@angular/forms";


@Component({
  selector: 'app-conditional-validation',
  templateUrl: './conditional-validation.component.html',
  styleUrls: ['./conditional-validation.component.css']
})
export class ConditionalValidationComponent implements OnInit
{
  public addressForm!: FormGroup;
  constructor(private fb:FormBuilder) {

  }
  ngOnInit(): void {
    this.addressForm = this.fb.group({
      street: ['', Validators.required],
      country: ['US'],
      postalCode: ['', [Validators.required, Validators.pattern('^[0-9]{5}(?:-[0-9]{4})?$')]]
  });

  this.addressForm.get('country')?.valueChanges.subscribe(
    (country: string) => {
      if (country === 'US') {
            
        this.addressForm.get('postalCode')?.setValidators([Validators.required, Validators.pattern('^[0-9]{5}(?:-[0-9]{4})?$')]);

    } 
    else if (country === 'CA') {
            
      this.addressForm.get('postalCode')?.setValidators([Validators.required, Validators.pattern('^[0-9]{3}(?:-[0-9]{2})?$')]);

  }

  this.addressForm.get('postalCode')?.updateValueAndValidity();

});

}

save(x:any) 
  {
    console.log(this.addressForm);

    if (this.addressForm.valid) {
       
      console.log('Saved: ' + JSON.stringify(this.addressForm.value));
    }
  }
}
